package dao;

import model.TypeOfClass;

import java.util.List;

public interface TypeOfClassDAO {
    List<TypeOfClass> findAllTypeOfClass();
}
