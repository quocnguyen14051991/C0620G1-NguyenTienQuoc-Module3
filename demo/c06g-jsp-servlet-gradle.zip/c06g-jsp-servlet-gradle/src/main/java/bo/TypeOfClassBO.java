package bo;

import model.TypeOfClass;

import java.util.List;

public interface TypeOfClassBO {
    List<TypeOfClass> findAllTypeOfClass();
}
