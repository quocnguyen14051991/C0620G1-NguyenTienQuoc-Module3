Apache OpenJPA - README.txt
Licensed under Apache License 2.0 - http://www.apache.org/licenses/LICENSE-2.0
--------------------------------------------------------------------------------

Thank you for downloading this release of Apache OpenJPA.

Please refer to the following files for more information:
    BUILDING.txt
    CHANGES.txt
    RELEASE-NOTES.html

For documentation and project information, please visit our project site:
    http://openjpa.apache.org/



